#!/usr/bin/env python3
"""UI/মোশন-গ্রাফিক্স ধাঁচের ছোট SFX সিন্থেসাইজ করে public/sfx/*.wav লেখে।
কোনো সাধারণ sine/square বীপ নয়: pitch-drop pop, filtered noise click/whoosh, soft-overtone chime।"""
import numpy as np, wave, os
from scipy import signal
SR = 44100
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), "..", "public", "sfx")
os.makedirs(OUT, exist_ok=True)

def t_(d): return np.arange(int(SR * d)) / SR
def lp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, "low", fs=SR, output="sos"), x)
def hp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, "high", fs=SR, output="sos"), x)
def env(t, a, tau): return np.minimum(1, t / a) * np.exp(-t / tau)
def reverb(x, amt=0.12, ln=0.07):
    n = int(SR * ln); ir = rng.standard_normal(n) * np.exp(-np.arange(n) / (SR * ln / 4)); ir[0] = 0
    wet = signal.fftconvolve(x, ir)[: len(x)]
    wet = wet / (np.max(np.abs(wet)) + 1e-9) * np.max(np.abs(x))
    return x * (1 - amt) + wet * amt
def fade(x, ms=6):
    n = int(SR * ms / 1000); x = x.copy(); x[-n:] *= np.linspace(1, 0, n); x[:2] *= 0.5; return x
def sweep_noise(d, f0, f1, bw, peak=0.4, shape=2.0):
    n = int(SR * d); noise = rng.standard_normal(n)
    f, tt, Z = signal.stft(noise, SR, nperseg=1024, noverlap=768)
    cf = np.exp(np.interp(tt, [0, tt[-1]], [np.log(f0), np.log(f1)]))
    mask = np.exp(-0.5 * ((np.log(f[:, None] + 1) - np.log(cf[None, :])) / bw) ** 2)
    _, y = signal.istft(Z * mask, SR, nperseg=1024, noverlap=768); y = y[:n]
    tt2 = np.arange(len(y)) / SR / d
    e = np.sin(np.pi * np.clip(tt2 ** peak, 0, 1)) ** shape  # নরম attack, মসৃণ decay
    return y * e

def pop():
    t = t_(0.24); f = 150 + 420 * np.exp(-t / 0.028)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = (np.sin(ph) + 0.22 * np.sin(2 * ph)) * env(t, 0.004, 0.05)
    return reverb(lp(x, 5500))
def click():
    t = t_(0.11); n = hp(rng.standard_normal(len(t)), 2200) * env(t, 0.0008, 0.011)
    tone = np.sin(2 * np.pi * 1700 * t) * env(t, 0.001, 0.008) * 0.35
    return lp(n * 0.8 + tone, 8500)
def swish():
    return reverb(lp(sweep_noise(0.36, 700, 2600, 0.55, peak=0.8, shape=2), 6500), 0.1)
def whoosh():
    return reverb(lp(sweep_noise(0.72, 350, 3200, 0.6, peak=0.75, shape=2.2), 6000), 0.12)
def thud():
    t = t_(0.46); f = 46 + 40 * np.exp(-t / 0.05)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * env(t, 0.008, 0.12) + 0.2 * lp(rng.standard_normal(len(t)), 220) * env(t, 0.002, 0.02)
    return lp(x, 380)
def chime():
    t = t_(0.62); x = np.zeros_like(t)
    for fr, a, tau in [(880, 1, 0.19), (1318.5, 0.5, 0.13), (1760, 0.32, 0.09), (2637, 0.12, 0.05)]:
        x += a * np.sin(2 * np.pi * fr * t + 0.3) * env(t, 0.004, tau)
        x += a * 0.4 * np.sin(2 * np.pi * fr * 1.003 * t) * env(t, 0.004, tau)
    return reverb(lp(x, 7000), 0.16, 0.09)

SOUNDS = dict(pop=pop, click=click, swish=swish, whoosh=whoosh, thud=thud, chime=chime)
PEAK = 0.8
print("name      dur(s)  peak   rms(active)  clipping")
for name, fn in SOUNDS.items():
    x = fade(fn()); x = x / np.max(np.abs(x)) * PEAK
    # active-RMS ম্যাচ: অ্যাকটিভ অংশের RMS প্রায় সমান রাখতে পিক নয়, তবে clip-মুক্ত রাখা
    act = x[np.abs(x) > 0.02 * PEAK]; rms = float(np.sqrt(np.mean(act ** 2)))
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with wave.open(os.path.join(OUT, f"{name}.wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    print(f"{name:8s}  {len(x)/SR:5.2f}  {np.max(np.abs(x)):.2f}   {rms:.3f}        {'NO' if np.max(np.abs(pcm))<32767 else 'YES'}")
