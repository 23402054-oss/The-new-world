import React from "react";
import { Composition } from "remotion";
import { Main, TOTAL_FRAMES } from "./Main";
import { FPS, HEIGHT, WIDTH } from "./config";

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
