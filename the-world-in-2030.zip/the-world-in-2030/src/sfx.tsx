import React from "react";
import { Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { SFX_ENABLED } from "./config";

// প্রতিটি সাউন্ডের দৈর্ঘ্য (সেকেন্ড) ও ডিফল্ট ভলিউম (০.২–০.৩৫, ভয়েসওভারের নিচে)
export const SFX = {
  pop: { len: 0.24, vol: 0.28 },
  click: { len: 0.11, vol: 0.24 },
  swish: { len: 0.36, vol: 0.26 },
  whoosh: { len: 0.72, vol: 0.3 },
  thud: { len: 0.46, vol: 0.3 },
  chime: { len: 0.62, vol: 0.26 },
} as const;
export type SfxName = keyof typeof SFX;

/** `at` ফ্রেমে (বর্তমান Sequence-এর সাপেক্ষে) সাউন্ড বাজায়। ভিজ্যুয়াল ল্যান্ড করার ২–৩ ফ্রেম আগে দিন। */
export const Sfx: React.FC<{ name: SfxName; at: number; vol?: number; rate?: number }> = ({ name, at, vol, rate = 1 }) => {
  const { fps } = useVideoConfig();
  if (!SFX_ENABLED) return null;
  const s = SFX[name];
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={Math.ceil(s.len * fps) + 2} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol ?? s.vol} playbackRate={rate} />
    </Sequence>
  );
};
