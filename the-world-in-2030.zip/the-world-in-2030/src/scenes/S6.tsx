import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Beat, Glass, SceneShell, Words, prog, useBreathe, useScene, useSp } from "../components/core";
import { ChipIcon, PersonIcon } from "../components/icons";
import { Sfx } from "../sfx";

const Rings: React.FC<{ cx: number; cy: number; color: string; on: number; dir: number }> = ({ cx, cy, color, on, dir }) => {
  const frame = useCurrentFrame();
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}>
      {[250, 300].map((r, i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={3} strokeDasharray={i ? "6 18" : "40 24"} opacity={on * (i ? 0.45 : 0.8)} transform={`rotate(${dir * frame * (i ? -0.9 : 1.2)} ${cx} ${cy})`} />
      ))}
    </svg>
  );
};

// সিন ৬ — Before/After Split (মানুষ বনাম প্রযুক্তি)
export const S6: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const b1 = sc.beat(1);
  const b2 = sc.beat(2);
  const q = useSp(0, theme.spring.bouncy);
  const split = useSp(b1, theme.spring.smooth);
  const flip = prog(frame, b2, 16, theme.ease.inOut);
  const br = useBreathe();
  const humanCtl = flip; // বিট ২-এ প্রযুক্তি মানুষকে নিয়ন্ত্রণ করে
  const techCtl = 1 - flip;
  const badge = interpolate(flip, [0, 1], [1, -1]);
  const slide = (frame * 2.2) % 40;
  return (
    <SceneShell>
      <Beat k={0}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center" }}>
          <Words text="সবচেয়ে বড় প্রশ্ন..." per={5} size={theme.size.head} align="center" />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 280, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 620, lineHeight: 1, transform: `scale(${q}) translateY(${br.y}px)`, backgroundImage: `linear-gradient(180deg, ${theme.colors.primary}, ${theme.colors.text} 130%)`, WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", color: "transparent", filter: `drop-shadow(0 0 50px ${theme.colors.glow})` }}>?</div>
        <Sfx name="thud" at={0} />
        <Sfx name="swish" at={3} />
        <Sfx name="chime" at={12} rate={0.9} />
      </Beat>

      <div style={{ position: "absolute", left: 110, top: 90, width: 820, height: 680, opacity: Math.min(1, split * 1.5), transform: `translateX(${(1 - split) * -140}px)` }}>
        <Glass accent style={{ inset: 0 }} />
        <div style={{ position: "absolute", left: 230, top: 70, transform: `scale(${1 + humanCtl * -0.06})`, opacity: 1 - humanCtl * 0.25, filter: `drop-shadow(0 0 ${30 - humanCtl * 20}px ${theme.colors.accentGlow})` }}><PersonIcon size={360} color={theme.colors.accent} p={split} /></div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 455, textAlign: "center" }}><Words text="মানুষ" per={3} size={theme.size.hero - 70} start={b1 + 4} align="center" color={theme.colors.accent} /></div>
      </div>
      <div style={{ position: "absolute", left: 990, top: 90, width: 820, height: 680, opacity: Math.min(1, split * 1.5), transform: `translateX(${(1 - split) * 140}px)` }}>
        <Glass style={{ inset: 0 }} />
        <div style={{ position: "absolute", left: 230, top: 70, transform: `scale(${1 + techCtl * -0.06})`, opacity: 1 - techCtl * 0.25, filter: `drop-shadow(0 0 ${30 + humanCtl * 20}px ${theme.colors.glow})` }}><ChipIcon size={360} p={split} glow /></div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 455, textAlign: "center" }}><Words text="প্রযুক্তি" per={3} size={theme.size.hero - 70} start={b1 + 6} align="center" color={theme.colors.primary} /></div>
      </div>
      <Rings cx={1400} cy={310} color={theme.colors.primary} on={split * techCtl} dir={1} />
      <Rings cx={520} cy={310} color={theme.colors.accent} on={split * humanCtl} dir={-1} />

      <div style={{ position: "absolute", left: 960 - 84, top: 420 - 84, width: 168, height: 168, borderRadius: 84, background: theme.colors.bg, border: `4px solid ${theme.colors.primary}`, transform: `scale(${split})`, boxShadow: theme.shadow.glow, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg width={168} height={168} viewBox="0 0 168 168" style={{ transform: `scaleX(${badge})` }}>
          {[0, 1, 2].map((i) => {
            const x = 40 + i * 34 + slide * 0.85 - 34;
            const o = Math.max(0, Math.min(1, 1 - Math.abs(x - 84) / 62));
            return <path key={i} d={`M${x} 56 L${x + 26} 84 L${x} 112`} fill="none" stroke={theme.colors.text} strokeWidth={13} strokeLinecap="round" strokeLinejoin="round" opacity={o} />;
          })}
        </svg>
      </div>

      <Beat k={1}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 830, display: "flex", justifyContent: "center" }}>
          <Words text="মানুষ কি প্রযুক্তিকে নিয়ন্ত্রণ করবে" per={4} size={76} align="center" hi={[3]} maxWidth={1500} />
        </div>
        <Sfx name="whoosh" at={0} vol={0.2} rate={1.1} />
        <Sfx name="pop" at={6} />
        <Sfx name="click" at={22} />
      </Beat>
      <Beat k={2}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 830, display: "flex", justifyContent: "center" }}>
          <Words text="নাকি প্রযুক্তিই নিয়ন্ত্রণ করবে মানুষকে?" per={4} size={76} align="center" hi={[2, 3]} hiAccent maxWidth={1500} />
        </div>
        <Sfx name="swish" at={0} />
        <Sfx name="click" at={8} rate={0.9} />
        <Sfx name="thud" at={10} vol={0.22} />
      </Beat>
    </SceneShell>
  );
};
