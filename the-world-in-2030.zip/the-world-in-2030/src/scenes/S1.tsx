import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Beat, MaskLine, SceneShell, Sweep, Words, prog, useScene, useSp } from "../components/core";
import { Globe } from "../components/Globe";
import { Sfx } from "../sfx";

// সিন ১ — হুক: Kinetic Typography + ডট-গ্লোব
export const S1: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const gp = useSp(0, theme.spring.smooth);
  const b2 = sc.beat(2);
  const hit = useSp(b2, theme.spring.bouncy);
  const pulse = 1 + 0.05 * Math.sin(Math.min(1, prog(frame, b2, 20)) * Math.PI);
  const rot = 40 + frame * 0.5 + (1 - gp) * 70;
  const ring = prog(frame, b2, 34, theme.ease.out);
  return (
    <SceneShell>
      <div style={{ position: "absolute", left: 880, top: 40, width: 1000, height: 1000, transform: `scale(${(0.7 + 0.3 * gp) * pulse})`, opacity: Math.min(1, gp * 1.6) }}>
        <Globe size={1000} rot={rot} frame={frame} glow={1 + 0.35 * Math.sin(Math.min(1, prog(frame, b2, 24)) * Math.PI)} />
        <div style={{ position: "absolute", left: 120, top: 120, width: 760, height: 760, borderRadius: "50%", border: `3px solid ${theme.colors.primary}`, opacity: (1 - ring) * 0.7, transform: `scale(${1 + ring * 0.55})` }} />
      </div>

      <Beat k={0}>
        <div style={{ position: "absolute", left: 120, top: 200 }}>
          <Words text="ভাবুন তো..." per={5} size={76} color={theme.colors.textDim} />
          <div style={{ marginTop: 6 }}>
            <MaskLine start={6}>
              <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: theme.size.mega, lineHeight: 1.05, letterSpacing: 0, backgroundImage: `linear-gradient(95deg, ${theme.colors.primary}, ${theme.colors.text} 120%)`, WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", color: "transparent", filter: `drop-shadow(0 0 36px ${theme.colors.glow})`, padding: "0 0.04em" }}>২০৩০</div>
            </MaskLine>
          </div>
          <div style={{ marginTop: 14 }}>
            <Words text="সালের পৃথিবী!" start={16} per={5} size={theme.size.head} />
          </div>
        </div>
        <Sfx name="thud" at={0} />
        <Sfx name="swish" at={4} rate={1.04} />
        <Sfx name="pop" at={13} rate={1.1} />
      </Beat>

      <Beat k={1}>
        <div style={{ position: "absolute", left: 120, top: 270, width: 820 }}>
          <Words text="প্রযুক্তি" per={4} size={theme.size.hero} hi={[0]} />
          <div style={{ marginTop: 12 }}>
            <Words text="শুধু জীবন সহজ করবে না" start={10} per={4} size={theme.size.sub} maxWidth={800} color={theme.colors.text} />
          </div>
        </div>
        <Sfx name="swish" at={2} />
      </Beat>

      <Beat k={2}>
        <div style={{ position: "absolute", left: 120, top: 260, width: 840 }}>
          <Words text="বদলে দেবে" per={4} size={theme.size.sub} color={theme.colors.textDim} />
          <div style={{ marginTop: 8 }}>
            <Words text="পুরো" start={8} per={4} size={theme.size.hero} />
            <div style={{ marginTop: 4 }}>
              <Words text="মানবসভ্যতা" start={14} per={4} size={theme.size.hero - 10} hi={[0]} />
            </div>
          </div>
        </div>
        <Sfx name="swish" at={2} />
        <Sfx name="thud" at={6} vol={0.24} />
      </Beat>
    </SceneShell>
  );
};
