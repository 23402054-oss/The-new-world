import React from "react";
import { Sequence, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { DrawPath, Glass, Pill, SceneShell, Words, prog, useBreathe, useScene, useSp } from "../components/core";
import { CapIcon, CheckIcon } from "../components/icons";
import { Sfx } from "../sfx";

const ECG = "M10 70 H110 L135 70 L155 20 L185 120 L210 70 H300 L322 70 L340 38 L360 92 L378 70 H470 L490 70 L508 46 L526 86 L542 70 H690";

const Scan: React.FC<{ start: number }> = ({ start }) => {
  const frame = useCurrentFrame() - start;
  const p = prog(frame, 0, 24);
  const sweep = ((frame - 10) % 80) / 80;
  const y = 40 + sweep * 300;
  const mark = prog(frame, 56, 14, theme.ease.out);
  const ecg = prog(frame, 30, 50, theme.ease.inOut);
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 800, height: 600 }}>
      <svg width={800} height={420} viewBox="0 0 800 420" style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
        <g transform="translate(400 0)">
          <circle cx="0" cy="62" r="46" fill="none" stroke={theme.colors.textDim} strokeWidth="4" opacity={p} />
          <DrawPath d="M-96 340 C-96 200 -70 130 0 130 C70 130 96 200 96 340" p={p} color={theme.colors.textDim} width={4} />
          <DrawPath d="M-96 170 L-150 300 M96 170 L150 300" p={p} color={theme.colors.textDim} width={4} />
          <rect x="-150" y={y - 6} width="300" height="12" rx="6" fill={theme.colors.primary} opacity={0.9 * p} style={{ filter: `drop-shadow(0 0 16px ${theme.colors.primary})` }} />
          <rect x="-150" y={y - 70} width="300" height="64" fill={theme.colors.glowSoft} opacity={p} />
          <circle cx="-34" cy="210" r={30 * mark} fill="none" stroke={theme.colors.accent} strokeWidth="5" style={{ filter: `drop-shadow(0 0 12px ${theme.colors.accent})` }} />
          <circle cx="-34" cy="210" r={9 * mark} fill={theme.colors.accent} />
        </g>
      </svg>
      <div style={{ position: "absolute", left: 40, top: 150, opacity: mark, transform: `translateX(${(1 - mark) * -30}px)` }}>
        <Pill accent size={36}>শনাক্ত</Pill>
      </div>
      <svg width={800} height={140} viewBox="0 0 700 140" style={{ position: "absolute", left: 50, top: 450, overflow: "visible" }}>
        <DrawPath d={ECG} p={ecg} color={theme.colors.primary} width={5} glow />
      </svg>
    </div>
  );
};

const Learn: React.FC = () => {
  const frame = useCurrentFrame();
  const br = useBreathe(1);
  const cap = useSp(4, theme.spring.bouncy);
  const line = prog(frame, 24, 56, theme.ease.inOut);
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 800, height: 600 }}>
      <div style={{ position: "absolute", left: 250, top: 10 + br.y, transform: `scale(${cap * br.s})`, filter: `drop-shadow(0 0 30px ${theme.colors.glow})` }}>
        <CapIcon size={300} p={Math.min(1, cap)} />
      </div>
      <div style={{ position: "absolute", left: 110, top: 410, width: 580, height: 6, borderRadius: 3, background: theme.colors.line }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${line * 100}%`, borderRadius: 3, background: theme.colors.primary, boxShadow: theme.shadow.glow }} />
      </div>
      {[0, 1, 2, 3].map((i) => {
        const on = prog(frame, 28 + i * 14, 10);
        return (
          <div key={i} style={{ position: "absolute", left: 110 + i * (580 / 3) - 34, top: 413 - 34, width: 68, height: 68, borderRadius: 34, background: on > 0.3 ? theme.colors.bg : theme.colors.glass, border: `3px solid ${on > 0.3 ? theme.colors.primary : theme.colors.lineStrong}`, transform: `scale(${0.8 + 0.2 * on})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <CheckIcon size={40} p={on} />
          </div>
        );
      })}
    </div>
  );
};

// সিন ৩ — Glass Cards (দুই কার্ড)
export const S3: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const b1 = sc.beat(1);
  const a = useSp(0, theme.spring.smooth);
  const b = useSp(b1, theme.spring.smooth);
  const dim = prog(frame, b1, 20);
  const shift = prog(frame, b1 - 8, 26, theme.ease.inOut);
  const br = useBreathe();
  return (
    <SceneShell>
      <div style={{ position: "absolute", left: 560 - 450 * shift, top: 130, width: 800, height: 820, opacity: Math.min(1, a * 1.5) * (1 - dim * 0.4), transform: `translateY(${(1 - a) * 110 + br.y}px) scale(${(0.94 + 0.06 * a) * (1 - dim * 0.03)})` }}>
        <Glass style={{ inset: 0 }} />
        <div style={{ position: "absolute", left: 50, top: 44 }}><Pill size={34}>AI</Pill></div>
        <div style={{ position: "absolute", left: 50, top: 100 }}><Words text="হাসপাতালে" per={4} size={theme.size.head - 6} /></div>
        <div style={{ position: "absolute", left: 0, top: 240 }}><Scan start={0} /></div>
      </div>
      <div style={{ position: "absolute", left: 1010, top: 130, width: 800, height: 820, opacity: Math.min(1, b * 1.5), transform: `translateX(${(1 - b) * 140}px) translateY(${br.y * -1}px) scale(${0.94 + 0.06 * b})` }}>
        {frame >= b1 - 2 && (
          <>
            <Glass style={{ inset: 0 }} />
            <div style={{ position: "absolute", left: 50, top: 44 }}><Pill size={34}>AI শিক্ষক</Pill></div>
            <div style={{ position: "absolute", left: 50, top: 100 }}><Words text="শিক্ষার্থীরা" start={b1 + 2} per={4} size={theme.size.head - 6} /></div>
            <div style={{ position: "absolute", left: 0, top: 260 }}><LearnShift start={b1} /></div>
          </>
        )}
      </div>
      <Sfx name="whoosh" at={0} vol={0.18} rate={1.15} />
      <Sfx name="pop" at={5} />
      <Sfx name="click" at={60} />
      <Sfx name="pop" at={b1 + 2} rate={1.08} />
      <Sfx name="click" at={b1 + 32} rate={1.05} />
      <Sfx name="click" at={b1 + 46} rate={1.1} />
      <Sfx name="click" at={b1 + 60} rate={1.14} />
      <Sfx name="chime" at={b1 + 70} />
    </SceneShell>
  );
};

const LearnShift: React.FC<{ start: number }> = ({ start }) => (
  <Sequence from={start} layout="none"><Learn /></Sequence>
);
