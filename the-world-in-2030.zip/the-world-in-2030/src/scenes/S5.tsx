import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Beat, Glass, Pill, SceneShell, Words, prog, useBreathe, useScene, useSp } from "../components/core";
import { ShieldIcon, ThermoIcon, WarnIcon } from "../components/icons";
import { Sfx } from "../sfx";

const wave = (frame: number, w: number, base: number, amp: number, k: number, ph: number) => {
  let d = `M0 ${base}`;
  for (let x = 0; x <= w; x += 16) d += ` L${x} ${base + Math.sin((x + frame * k + ph) / 55) * amp}`;
  return d + ` L${w} 700 L0 700 Z`;
};

const Climate: React.FC<{ start: number }> = ({ start }) => {
  const f = useCurrentFrame() - start;
  const rise = prog(f, 10, 70, theme.ease.inOut);
  const sun = 1 + 0.04 * Math.sin(f / 16);
  return (
    <svg width={650} height={440} viewBox="0 0 650 440" style={{ position: "absolute", left: 0, top: 0 }}>
      <g transform={`translate(325 130) scale(${sun})`}>
        <circle r="150" fill={theme.colors.accentGlow} opacity={0.35} style={{ filter: "blur(30px)" }} />
        <circle r="70" fill={theme.colors.accent} style={{ filter: `drop-shadow(0 0 30px ${theme.colors.accent})` }} />
        {Array.from({ length: 12 }, (_, i) => <line key={i} x1="0" y1="-98" x2="0" y2="-124" stroke={theme.colors.accent} strokeWidth="6" strokeLinecap="round" transform={`rotate(${i * 30 + f * 0.8})`} />)}
      </g>
      <path d={wave(f, 650, 330 - rise * 40, 12, 4, 0)} fill={theme.colors.primary} opacity={0.32} />
      <path d={wave(f, 650, 360 - rise * 46, 10, 5, 90)} fill={theme.colors.primary} opacity={0.5} />
    </svg>
  );
};

const Heat: React.FC<{ start: number }> = ({ start }) => {
  const f = useCurrentFrame() - start;
  const lvl = 0.25 + 0.75 * prog(f, 8, 60, theme.ease.inOut);
  const tp = prog(f, 0, 20);
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1020, height: 250 }}>
      <div style={{ position: "absolute", left: 70, top: 16, filter: `drop-shadow(0 0 24px ${theme.colors.accentGlow})` }}><ThermoIcon size={190} p={tp} level={lvl} glow /></div>
      <svg width={560} height={200} viewBox="0 0 560 230" style={{ position: "absolute", left: 380, top: 0 }}>
        {[0, 1, 2, 3, 4].map((i) => {
          let d = `M${30 + i * 110} 220`;
          for (let y = 220; y >= 10; y -= 10) d += ` L${30 + i * 110 + Math.sin((y + f * 3 + i * 40) / 22) * 16} ${y}`;
          return <path key={i} d={d} fill="none" stroke={theme.colors.accent} strokeWidth="5" strokeLinecap="round" opacity={(0.25 + 0.4 * Math.sin(f / 12 + i)) * tp} />;
        })}
      </svg>
    </div>
  );
};

const Secure: React.FC<{ start: number }> = ({ start }) => {
  const f = useCurrentFrame() - start;
  const tp = prog(f, 0, 22);
  const br = useBreathe();
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1020, height: 250 }}>
      <div style={{ position: "absolute", left: 80, top: 22 + br.y, filter: `drop-shadow(0 0 28px ${theme.colors.glow})` }}><ShieldIcon size={180} p={tp} glow /></div>
      {Array.from({ length: 9 }, (_, i) => {
        const t = ((f * 0.02 + i * 0.113) % 1);
        const row = i % 3;
        return <div key={i} style={{ position: "absolute", left: 320 + t * 640, top: 40 + row * 70, width: 54 + (i % 3) * 22, height: 18, borderRadius: 9, background: t > 0.8 ? theme.colors.primary : theme.colors.textDim, opacity: tp * (0.15 + 0.6 * Math.sin(t * Math.PI)) }} />;
      })}
    </div>
  );
};

// সিন ৫ — Bento Grid (চ্যালেঞ্জ)
export const S5: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const b1 = sc.beat(1);
  const b2 = sc.beat(2);
  const tB = b1 + Math.round((b2 - b1) / 2);
  const mix = prog(frame, 0, 36);
  const a = useSp(b1, theme.spring.smooth);
  const b = useSp(tB, theme.spring.smooth);
  const c = useSp(b2, theme.spring.smooth);
  const head = prog(frame, b1 - 6, 24, theme.ease.inOut);
  const warn = useSp(0, theme.spring.bouncy);
  const br = useBreathe();
  const tile = (p: number, dx: number, dy: number): React.CSSProperties => ({ opacity: Math.min(1, p * 1.5), transform: `translate(${(1 - p) * dx}px, ${(1 - p) * dy}px) scale(${0.92 + 0.08 * p})` });
  return (
    <SceneShell accentMix={mix}>
      <Beat k={0}>
        <div style={{ position: "absolute", left: 710, top: 90, transform: `scale(${warn})`, filter: `drop-shadow(0 0 40px ${theme.colors.accentGlow})` }}><WarnIcon size={500} p={Math.min(1, warn)} glow /></div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 640, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <Words text="কিন্তু এই উন্নতির মাঝেই থাকবে" per={3} size={theme.size.sub - 6} align="center" color={theme.colors.textDim} maxWidth={1500} />
          <div style={{ marginTop: 8 }}><Words text="বড় চ্যালেঞ্জ" start={14} per={5} size={theme.size.hero - 20} hi={[0, 1]} hiAccent align="center" /></div>
        </div>
        <Sfx name="thud" at={0} />
        <Sfx name="swish" at={3} rate={0.95} />
        <Sfx name="pop" at={16} rate={0.9} />
      </Beat>

      <div style={{ position: "absolute", left: 110, top: 96, opacity: head, transform: `translateX(${(1 - head) * -40}px)`, display: "flex", alignItems: "center", gap: 28 }}>
        <div style={{ width: 90, height: 90 }}><WarnIcon size={90} p={head} /></div>
        <Words text="বড় চ্যালেঞ্জ" start={b1 - 2} per={4} size={theme.size.head} hi={[0, 1]} hiAccent />
      </div>

      <div style={{ position: "absolute", left: 110, top: 300, width: 650, height: 680, ...tile(a, -80, 40) }}>
        <Glass accent style={{ inset: 0 }} />
        <div style={{ position: "absolute", left: 0, top: 0 }}><Climate start={b1} /></div>
        <div style={{ position: "absolute", left: 44, top: 470 }}><Words text="জলবায়ু পরিবর্তন" start={b1 + 6} per={5} size={theme.size.sub + 4} maxWidth={580} /></div>
      </div>
      <div style={{ position: "absolute", left: 790, top: 300, width: 1020, height: 330, ...tile(b, 80, -30) }}>
        <Glass accent style={{ inset: 0 }} />
        <div style={{ position: "absolute", left: 0, top: 0 }}><Heat start={tB} /></div>
        <div style={{ position: "absolute", left: 44, top: 218 }}><Words text="ভয়াবহ তাপপ্রবাহ" start={tB + 6} per={5} size={theme.size.sub - 10} /></div>
      </div>
      <div style={{ position: "absolute", left: 790, top: 650, width: 1020, height: 330, ...tile(c, 80, 40) }}>
        <Glass style={{ inset: 0 }} />
        <div style={{ position: "absolute", left: 0, top: 0 }}><Secure start={b2} /></div>
        <div style={{ position: "absolute", left: 44, top: 218 }}><Words text="ব্যক্তিগত তথ্যের নিরাপত্তা" start={b2 + 6} per={4} size={theme.size.sub - 12} /></div>
      </div>
      <Sfx name="whoosh" at={b1 - 8} vol={0.2} rate={1.1} />
      <Sfx name="pop" at={b1 + 1} />
      <Sfx name="pop" at={tB + 1} rate={1.08} />
      <Sfx name="pop" at={b2 + 1} rate={1.16} />
      <Sfx name="click" at={b2 + 20} />
    </SceneShell>
  );
};
