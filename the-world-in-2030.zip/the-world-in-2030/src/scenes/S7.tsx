import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Beat, Glass, MaskLine, SceneShell, Words, prog, useBreathe, useScene, useSp } from "../components/core";
import { Globe } from "../components/Globe";
import { Sfx } from "../sfx";

const font = theme.fonts.display;
const gradText = (c1: string, c2: string): React.CSSProperties => ({ backgroundImage: `linear-gradient(95deg, ${c1}, ${c2} 125%)`, WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", color: "transparent" });

// সিন ৭ — Statement Card → সমাপ্তি
export const S7: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const b1 = sc.beat(1);
  const b2 = sc.beat(2);
  const card = useSp(0, theme.spring.smooth);
  const flip = prog(frame, b1, 26, theme.ease.inOut);
  const gone = prog(frame, b2 - 8, 18, theme.ease.in);
  const globe = useSp(b2, theme.spring.smooth);
  const br = useBreathe();
  const ring = ((frame - b2) / 70) % 1;
  const rotY = interpolate(flip, [0, 1], [0, 180]);
  return (
    <SceneShell fadeOut>
      <div style={{ position: "absolute", left: 410, top: 150 + br.y, width: 1100, height: 470, opacity: Math.min(1, card * 1.6) * (1 - gone), transform: `perspective(2200px) translateY(${(1 - card) * 90 - gone * 130}px) scale(${(0.9 + 0.1 * card) * (1 - gone * 0.2)}) rotateY(${rotY}deg)`, transformStyle: "preserve-3d" }}>
        <div style={{ position: "absolute", inset: 0, backfaceVisibility: "hidden" }}>
          <Glass style={{ inset: 0 }}>
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <MaskLine start={6}>
                <div style={{ fontFamily: font, fontWeight: 700, fontSize: theme.size.mega + 20, lineHeight: 1.05, letterSpacing: 0, padding: "0 0.05em", filter: `drop-shadow(0 0 36px ${theme.colors.glow})`, ...gradText(theme.colors.primary, theme.colors.text) }}>২০৩০</div>
              </MaskLine>
            </div>
          </Glass>
        </div>
        <div style={{ position: "absolute", inset: 0, backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}>
          <Glass style={{ inset: 0 }}>
            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
              <div style={{ fontFamily: font, fontWeight: 700, fontSize: theme.size.sub, lineHeight: 1.3, color: theme.colors.textDim }}>মানবসভ্যতার ইতিহাসে এক</div>
              <div style={{ fontFamily: font, fontWeight: 700, fontSize: theme.size.hero - 20, lineHeight: 1.3, letterSpacing: 0, padding: "0 0.05em", filter: `drop-shadow(0 0 30px ${theme.colors.glow})`, ...gradText(theme.colors.primary, theme.colors.text) }}>নতুন অধ্যায়</div>
            </div>
          </Glass>
        </div>
      </div>

      <Beat k={0}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 740, display: "flex", justifyContent: "center" }}>
          <Words text="শুধু একটি নতুন বছর নয়" start={10} per={4} size={theme.size.head - 10} align="center" hi={[3]} />
        </div>
        <Sfx name="thud" at={0} vol={0.22} />
        <Sfx name="swish" at={4} />
        <Sfx name="pop" at={8} rate={1.1} />
      </Beat>
      <Beat k={1}>
        <Sfx name="whoosh" at={2} vol={0.2} rate={1.1} />
        <Sfx name="chime" at={22} />
      </Beat>

      <div style={{ position: "absolute", left: 410, top: 520 + (1 - globe) * 320, width: 1100, height: 1100, opacity: Math.min(1, globe * 1.4) }}>
        <Globe size={1100} rot={30 + frame * 0.45} frame={frame} />
        {[0, 1].map((i) => {
          const t = (ring + i * 0.5) % 1;
          return <div key={i} style={{ position: "absolute", left: 190, top: 190, width: 720, height: 720, borderRadius: "50%", border: `3px solid ${theme.colors.primary}`, opacity: globe > 0.8 ? (1 - t) * 0.5 : 0, transform: `scale(${1 + t * 0.7})` }} />;
        })}
      </div>
      <Beat k={2}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center" }}>
          <Words text="আপনি কি সেই ভবিষ্যতের জন্য প্রস্তুত?" per={4} size={theme.size.title + 6} align="center" hi={[3, 5]} maxWidth={1500} />
        </div>
        <Sfx name="swish" at={0} />
        <Sfx name="chime" at={24} rate={1.1} />
      </Beat>
    </SceneShell>
  );
};
