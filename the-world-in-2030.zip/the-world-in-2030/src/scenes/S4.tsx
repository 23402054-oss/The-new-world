import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Beat, DrawPath, SceneShell, Words, prog, rnd, useScene, useSp } from "../components/core";
import { Sfx } from "../sfx";

const GROUND = 850;
// মিড-লেয়ার ভবন (স্থির — স্মার্ট নোড এখানে নোঙর করে)
const MID = Array.from({ length: 13 }, (_, i) => {
  const w = 120 + rnd(i * 3 + 1) * 80;
  return { x: 40 + i * 148 + rnd(i + 40) * 18, w, h: 190 + rnd(i * 3 + 2) * 250 };
});
const FAR = Array.from({ length: 26 }, (_, i) => ({ x: i * 150, w: 110 + rnd(i + 9) * 60, h: 120 + rnd(i * 2 + 5) * 230 }));
const NODE_IDS = [1, 3, 5, 7, 9, 11];

const Windows: React.FC<{ x: number; w: number; h: number; seed: number; frame: number }> = ({ x, w, h, seed, frame }) => {
  const cols = Math.floor(w / 34);
  const rows = Math.floor(h / 46);
  const out: React.ReactNode[] = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const on = rnd(seed * 100 + r * 9 + c) > 0.55;
      if (!on) continue;
      const tw = 0.5 + 0.5 * Math.sin(frame / 25 + r * 3 + c);
      out.push(<rect key={`${r}-${c}`} x={x + 16 + c * 34} y={GROUND - h + 22 + r * 46} width={14} height={20} rx={3} fill={theme.colors.primary} opacity={0.14 + 0.2 * tw} />);
    }
  return <>{out}</>;
};

const Car: React.FC<{ x: number; scan: number }> = ({ x, scan }) => {
  const frame = useCurrentFrame();
  const sweep = Math.sin(frame / 14) * 9;
  return (
    <g transform={`translate(${x} 0)`}>
      <ellipse cx="300" cy="1034" rx="360" ry="24" fill={theme.colors.primary} opacity={0.22} style={{ filter: "blur(14px)" }} />
      {/* সেন্সর কোণ */}
      <g opacity={scan}>
        <polygon points={`610,900 1180,${760 + sweep * 6} 1180,${1040 + sweep * 6}`} fill={theme.colors.primary} opacity={0.12} />
        <polygon points={`610,900 1180,${760 + sweep * 6} 1180,${1040 + sweep * 6}`} fill="none" stroke={theme.colors.primary} strokeWidth={2} opacity={0.35} />
        {[0, 1, 2].map((i) => {
          const t = ((frame / 40 + i / 3) % 1);
          return <circle key={i} cx={403} cy={850} r={30 + t * 200} fill="none" stroke={theme.colors.primary} strokeWidth={3} opacity={(1 - t) * 0.6} />;
        })}
      </g>
      <g transform="translate(0 827) scale(1.55)">
        <path d="M10 90 C10 70 30 62 60 58 L110 30 C120 24 140 22 170 22 L250 22 C275 22 292 30 305 46 L340 58 C372 62 390 72 390 92 L390 104 H10 Z" fill={theme.colors.carBody} />
        <path d="M122 36 C128 31 142 30 168 30 H208 V56 H100 Z M222 30 H250 C268 30 280 36 290 50 L296 56 H222 Z" fill={theme.colors.carGlass} />
        <rect x="10" y="88" width="380" height="5" fill={theme.colors.primary} opacity={0.9} />
        <rect x="364" y="68" width="24" height="9" rx="4" fill={theme.colors.primary} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.primary})` }} />
        <rect x="10" y="66" width="14" height="8" rx="4" fill={theme.colors.accent} />
        <circle cx="95" cy="106" r="25" fill={theme.colors.bg} stroke={theme.colors.carBody} strokeWidth="5" />
        <circle cx="305" cy="106" r="25" fill={theme.colors.bg} stroke={theme.colors.carBody} strokeWidth="5" />
        <circle cx="260" cy="14" r="7" fill={theme.colors.primary} style={{ filter: `drop-shadow(0 0 8px ${theme.colors.primary})` }} />
      </g>
    </g>
  );
};

// সিন ৪ — চালকবিহীন গাড়ি ও স্মার্ট শহর (ফ্ল্যাট ভেক্টর, লেয়ারড সিটিস্কেপ)
export const S4: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const b1 = sc.beat(1);
  const car = useSp(0, theme.spring.smooth);
  const carX = interpolate(car, [0, 1], [-800, 520]) + Math.sin(frame / 40) * 3;
  const scan = 1 - prog(frame, b1 + 20, 20);
  const farX = -(frame * 0.5) % 3900;
  const dash = -(frame * 9) % 160;
  const net = prog(frame, b1 + 8, 40);
  return (
    <SceneShell>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", left: 0, top: 0 }}>
        <g transform={`translate(${farX} 0)`} opacity={0.9}>
          {[0, 3900].map((o) => FAR.map((b, i) => <rect key={`${o}-${i}`} x={o + b.x} y={GROUND - b.h} width={b.w} height={b.h} fill={theme.colors.cityFar} />))}
        </g>
        {MID.map((b, i) => {
          const p = prog(frame, 4 + i * 3, 22);
          return (
            <g key={i} opacity={p} transform={`translate(0 ${(1 - p) * 70})`}>
              <rect x={b.x} y={GROUND - b.h} width={b.w} height={b.h} fill={theme.colors.cityMid} />
              <rect x={b.x} y={GROUND - b.h} width={b.w} height={4} fill={theme.colors.primary} opacity={0.35} />
              <Windows x={b.x} w={b.w} h={b.h} seed={i} frame={frame} />
            </g>
          );
        })}
        {/* স্মার্ট নেটওয়ার্ক */}
        {NODE_IDS.slice(0, -1).map((id, i) => {
          const A = MID[id], B = MID[NODE_IDS[i + 1]];
          const ax = A.x + A.w / 2, ay = GROUND - A.h - 46, bx = B.x + B.w / 2, by = GROUND - B.h - 46;
          const mx = (ax + bx) / 2, my = Math.min(ay, by) - 90;
          const p = Math.max(0, Math.min(1, net * 6 - i));
          const t = (frame / 60 + i * 0.3) % 1;
          const px = (1 - t) * (1 - t) * ax + 2 * (1 - t) * t * mx + t * t * bx;
          const py = (1 - t) * (1 - t) * ay + 2 * (1 - t) * t * my + t * t * by;
          return (
            <g key={i}>
              
              <DrawPath d={`M${ax} ${ay} Q${mx} ${my} ${bx} ${by}`} p={p} color={theme.colors.primary} width={3} opacity={0.8} />
              {p >= 1 && <circle cx={px} cy={py} r={7} fill={theme.colors.text} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.primary})` }} />}
            </g>
          );
        })}
        {NODE_IDS.map((id, i) => {
          const B = MID[id];
          const cx = B.x + B.w / 2, cy = GROUND - B.h - 46;
          const p = Math.max(0, Math.min(1, net * 6 - i + 0.5));
          const ping = (frame / 45 + i * 0.17) % 1;
          return (
            <g key={id} opacity={p}>
              <circle cx={cx} cy={cy} r={16 + ping * 34} fill="none" stroke={theme.colors.primary} strokeWidth={2.5} opacity={(1 - ping) * 0.7} />
              <circle cx={cx} cy={cy} r={15} fill={theme.colors.bg} stroke={theme.colors.primary} strokeWidth={4} />
              <circle cx={cx} cy={cy} r={5.5} fill={theme.colors.primary} />
            </g>
          );
        })}
        {/* রাস্তা */}
        <rect x="0" y={GROUND} width="1920" height="230" fill={theme.colors.road} />
        <rect x="0" y={GROUND} width="1920" height="5" fill={theme.colors.primary} opacity={0.85} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.primary})` }} />
        {Array.from({ length: 16 }, (_, i) => <rect key={i} x={dash + i * 160} y={1010} width={90} height={9} rx={4} fill={theme.colors.textDim} opacity={0.55} />)}
        <Car x={carX} scan={scan} />
      </svg>

      <Beat k={0}>
        <div style={{ position: "absolute", left: 110, top: 76 }}>
          <Words text="রাস্তায় বাড়বে" per={4} size={theme.size.sub} color={theme.colors.textDim} />
          <div style={{ marginTop: 4 }}><Words text="চালকবিহীন গাড়ি" start={8} per={5} size={theme.size.title} hi={[0]} /></div>
        </div>
        <Sfx name="swish" at={3} />
      </Beat>
      <Beat k={1}>
        <div style={{ position: "absolute", left: 110, top: 76 }}>
          <Words text="শহর পরিচালিত হবে" per={4} size={theme.size.sub} color={theme.colors.textDim} />
          <div style={{ marginTop: 4 }}><Words text="স্মার্ট প্রযুক্তির মাধ্যমে" start={8} per={5} size={theme.size.title - 8} hi={[0, 1]} maxWidth={1500} /></div>
        </div>
        <Sfx name="swish" at={3} />
        <Sfx name="pop" at={14} />
        <Sfx name="chime" at={50} rate={1.05} />
      </Beat>
      <Sfx name="whoosh" at={0} vol={0.18} rate={1.2} />
    </SceneShell>
  );
};
