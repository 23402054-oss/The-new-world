import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Beat, Glass, Pill, SceneShell, Words, prog, rnd, useBreathe, useScene, useSp } from "../components/core";
import { CheckIcon, PersonIcon, RobotIcon } from "../components/icons";
import { Sfx } from "../sfx";

const WIN = { x: 150, y: 110, w: 1620, h: 860, bar: 78 };

// ব্রেইন নেটওয়ার্ক নোড
const NODES = Array.from({ length: 34 }, (_, i) => {
  const a = rnd(i * 4 + 1) * Math.PI * 2;
  const r = Math.sqrt(rnd(i * 4 + 2));
  const lobe = i % 2 === 0 ? -1 : 1;
  return { x: 380 + Math.cos(a) * r * 300 + lobe * 0, y: 300 + Math.sin(a) * r * 230 };
});
const EDGES: [number, number][] = [];
NODES.forEach((n, i) => {
  NODES.map((m, j) => ({ j, d: Math.hypot(n.x - m.x, n.y - m.y) }))
    .filter((o) => o.j !== i)
    .sort((a, b) => a.d - b.d)
    .slice(0, 2)
    .forEach((o) => { if (!EDGES.some(([a, b]) => (a === i && b === o.j) || (a === o.j && b === i))) EDGES.push([i, o.j]); });
});

const Brain: React.FC = () => {
  const frame = useCurrentFrame();
  const chip = useSp(30, theme.spring.bouncy);
  return (
    <svg width={760} height={620} viewBox="0 0 760 620" style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
      {EDGES.map(([a, b], i) => {
        const p = prog(frame, 4 + i * 0.9, 18);
        const A = NODES[a], B = NODES[b];
        const t = ((frame * 0.03 + rnd(i + 70)) % 1);
        return (
          <g key={i}>
            <line x1={A.x} y1={A.y} x2={A.x + (B.x - A.x) * p} y2={A.y + (B.y - A.y) * p} stroke={theme.colors.lineStrong} strokeWidth={2} />
            {i % 3 === 0 && p >= 1 && frame > 40 && <circle cx={A.x + (B.x - A.x) * t} cy={A.y + (B.y - A.y) * t} r={5} fill={theme.colors.primary} style={{ filter: `drop-shadow(0 0 8px ${theme.colors.primary})` }} />}
          </g>
        );
      })}
      {NODES.map((n, i) => {
        const p = prog(frame, 2 + i * 0.8, 14, theme.ease.out);
        return <circle key={i} cx={n.x} cy={n.y} r={9 * p} fill={theme.colors.bgAlt} stroke={theme.colors.textDim} strokeWidth={2.5} />;
      })}
      <g transform={`translate(380 300) scale(${chip})`} opacity={Math.min(1, chip * 1.5)}>
        <rect x={-84} y={-84} width={168} height={168} rx={38} fill={theme.colors.bg} stroke={theme.colors.primary} strokeWidth={4} style={{ filter: `drop-shadow(0 0 30px ${theme.colors.primary})` }} />
        <text x={0} y={30} textAnchor="middle" fontFamily={theme.fonts.display} fontWeight={700} fontSize={92} fill={theme.colors.text}>AI</text>
      </g>
    </svg>
  );
};

const Together: React.FC = () => {
  const frame = useCurrentFrame();
  const a = useSp(0, theme.spring.smooth);
  const b = useSp(8, theme.spring.smooth);
  const fill = prog(frame, 26, 32, theme.ease.inOut);
  const meet = prog(frame, 58, 10);
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 760, height: 620 }}>
      <Glass style={{ left: 20, top: 40, width: 270, height: 340, opacity: a, transform: `translateY(${(1 - a) * 50}px)` }}>
        <div style={{ position: "absolute", left: 60, top: 60 }}><PersonIcon size={150} p={a} color={theme.colors.text} /></div>
      </Glass>
      <Glass style={{ left: 470, top: 40, width: 270, height: 340, opacity: b, transform: `translateY(${(1 - b) * 50}px)` }}>
        <div style={{ position: "absolute", left: 60, top: 60 }}><RobotIcon size={150} p={b} glow /></div>
      </Glass>
      {[0, 1, 2, 3].map((i) => {
        const t = ((frame * 0.035 + i * 0.25) % 1);
        const ltr = i % 2 === 0;
        return <div key={i} style={{ position: "absolute", top: 205 - 5, left: 300 + (ltr ? t : 1 - t) * 150, width: 12, height: 12, borderRadius: 6, background: ltr ? theme.colors.text : theme.colors.primary, opacity: Math.min(1, a * b * 2) * (0.35 + 0.65 * Math.sin(t * Math.PI)) }} />;
      })}
      <div style={{ position: "absolute", left: 300, top: 205, width: 150, height: 0, borderTop: `3px dashed ${theme.colors.lineStrong}`, opacity: a * b }} />
      <div style={{ position: "absolute", left: 20, top: 450, width: 720, height: 30, borderRadius: 15, background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassEdge}` }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 360 * fill, borderRadius: 15, background: theme.colors.text, opacity: 0.85 }} />
        <div style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: 360 * fill, borderRadius: 15, background: theme.colors.primary, boxShadow: theme.shadow.glow }} />
      </div>
      <div style={{ position: "absolute", left: 360 - 38, top: 428 - 0, width: 76, height: 76, borderRadius: 38, background: theme.colors.bg, border: `4px solid ${theme.colors.primary}`, transform: `scale(${meet})`, opacity: meet, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.glow }}>
        <CheckIcon size={44} p={meet} color={theme.colors.primary} />
      </div>
    </div>
  );
};

const ROWS = [300, 440, 360, 400];
const Assistant: React.FC = () => {
  const frame = useCurrentFrame();
  const typing = prog(frame, 0, 10);
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 760, height: 620 }}>
      <div style={{ position: "absolute", left: 0, top: 0, display: "flex", alignItems: "center", gap: 18, opacity: typing }}>
        <div style={{ width: 84, height: 84, borderRadius: 42, background: theme.colors.glowSoft, border: `2px solid ${theme.colors.primary}`, display: "flex", alignItems: "center", justifyContent: "center" }}><RobotIcon size={52} /></div>
        <div style={{ display: "flex", gap: 9 }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ width: 14, height: 14, borderRadius: 7, background: theme.colors.textDim, opacity: 0.4 + 0.6 * Math.max(0, Math.sin(frame / 5 - i * 0.9)) }} />)}
        </div>
      </div>
      {ROWS.map((w, i) => {
        const p = prog(frame, 12 + i * 7, 16);
        const tick = prog(frame, 30 + i * 10, 10);
        return (
          <div key={i} style={{ position: "absolute", left: 0, top: 120 + i * 118, width: 740, height: 96, opacity: p, transform: `translateX(${(1 - p) * 60}px)` }}>
            <div style={{ position: "absolute", inset: 0, borderRadius: 26, background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassEdge}` }} />
            <div style={{ position: "absolute", left: 26, top: 24, width: 48, height: 48, borderRadius: 24, border: `3px solid ${tick > 0.2 ? theme.colors.primary : theme.colors.lineStrong}`, background: tick > 0.2 ? theme.colors.glowSoft : "transparent" }}>
              <div style={{ position: "absolute", left: 2, top: 2 }}><CheckIcon size={40} p={tick} /></div>
            </div>
            <div style={{ position: "absolute", left: 100, top: 31, width: w * 1.05, height: 14, borderRadius: 7, background: theme.colors.text, opacity: 0.55 }} />
            <div style={{ position: "absolute", left: 100, top: 56, width: w * 0.55, height: 10, borderRadius: 5, background: theme.colors.textDim, opacity: 0.5 }} />
          </div>
        );
      })}
    </div>
  );
};

// সিন ২ — Glossy UI Mockup
export const S2: React.FC = () => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const w = useSp(0, theme.spring.smooth);
  const br = useBreathe();
  const dot = 0.5 + 0.5 * Math.sin(frame / 10);
  return (
    <SceneShell>
      <div style={{ position: "absolute", left: WIN.x, top: WIN.y, width: WIN.w, height: WIN.h, opacity: Math.min(1, w * 1.6), transform: `perspective(1800px) rotateX(${(1 - w) * 10}deg) translateY(${(1 - w) * 80 + br.y}px) scale(${0.92 + 0.08 * w})` }}>
        <Glass style={{ inset: 0, borderRadius: 44 }}>
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: WIN.bar, borderBottom: `1.5px solid ${theme.colors.glassEdge}` }}>
            {[0, 1, 2].map((i) => <div key={i} style={{ position: "absolute", left: 34 + i * 34, top: 30, width: 18, height: 18, borderRadius: 9, background: theme.colors.textDim, opacity: 0.45 }} />)}
            <div style={{ position: "absolute", left: 0, right: 0, top: 14, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 36, color: theme.colors.textDim, lineHeight: 1.4 }}>AI Assistant</div>
            <div style={{ position: "absolute", right: 44, top: 30, width: 18, height: 18, borderRadius: 9, background: theme.colors.primary, boxShadow: `0 0 ${14 + dot * 16}px ${theme.colors.primary}` }} />
          </div>
        </Glass>
        <div style={{ position: "absolute", left: 0, top: WIN.bar, width: WIN.w, height: WIN.h - WIN.bar }}>
          <Beat k={0}>
            <div style={{ position: "absolute", left: 80, top: 250, width: 700 }}>
              <Words text="কৃত্রিম বুদ্ধিমত্তা" per={4} size={theme.size.head - 6} />
              <div style={{ marginTop: 10 }}><Words text="প্রতিদিনের সঙ্গী" start={12} per={4} size={theme.size.head - 6} hi={[0, 1]} /></div>
            </div>
            <div style={{ position: "absolute", left: 800, top: 110 }}><Brain /></div>
            <Sfx name="whoosh" at={0} vol={0.2} rate={1.1} />
            <Sfx name="chime" at={28} rate={1.0} />
          </Beat>
          <Beat k={1}>
            <div style={{ position: "absolute", left: 80, top: 260, width: 700 }}>
              <Words text="রোবট কাজ করবে" per={4} size={theme.size.sub} color={theme.colors.textDim} />
              <div style={{ marginTop: 10 }}><Words text="মানুষের পাশাপাশি" start={10} per={4} size={theme.size.head - 6} hi={[1]} /></div>
            </div>
            <div style={{ position: "absolute", left: 800, top: 110 }}><Together /></div>
            <Sfx name="pop" at={0} />
            <Sfx name="pop" at={8} rate={1.12} />
            <Sfx name="click" at={56} />
          </Beat>
          <Beat k={2}>
            <div style={{ position: "absolute", left: 80, top: 220, width: 700 }}>
              <Words text="ব্যক্তিগত" per={4} size={theme.size.sub} color={theme.colors.textDim} />
              <div style={{ marginTop: 6 }}><Words text="AI Assistant" start={8} per={5} size={theme.size.head + 8} hi={[0, 1]} /></div>
              <div style={{ marginTop: 14 }}><Words text="আপনার হয়ে অনেক কাজ" start={20} per={4} size={theme.size.sub - 6} maxWidth={700} /></div>
            </div>
            <div style={{ position: "absolute", left: 800, top: 110 }}><Assistant /></div>
            <Sfx name="pop" at={6} />
            <Sfx name="click" at={28} />
            <Sfx name="click" at={38} rate={1.06} />
            <Sfx name="click" at={48} rate={1.1} />
            <Sfx name="click" at={58} rate={1.04} />
          </Beat>
        </div>
      </div>
    </SceneShell>
  );
};
