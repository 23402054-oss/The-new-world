export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** ভিজ্যুয়াল সংশ্লিষ্ট কথার এত ফ্রেম আগে ঢোকে (৪–৬ ফ্রেম) */
export const LEAD = 5;

/** public/voiceover.mp3 থাকলে Remotion Studio-তে প্রিভিউ চলবে। */
export const PREVIEW_VOICEOVER = true;
/** রেন্ডারে voiceover মেশাতে চাইলে true করুন (ডিফল্ট: বন্ধ — ভিডিওতে শুধু SFX)। */
export const RENDER_WITH_VOICEOVER = false;
/** সব SFX এক সুইচে বন্ধ করতে false */
export const SFX_ENABLED = true;
