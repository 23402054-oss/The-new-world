import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { PREVIEW_VOICEOVER, RENDER_WITH_VOICEOVER } from "./config";

/** public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ। Studio-তে ডিফল্ট চালু; রেন্ডারে ডিফল্ট বন্ধ। */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const wanted = env.isRendering ? RENDER_WITH_VOICEOVER : PREVIEW_VOICEOVER;
  const [handle] = useState(() => (wanted ? delayRender("voiceover-check") : null));
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (handle === null) return;
    const done = () => continueRender(handle);
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        setExists(r.ok && /audio|mpeg|octet-stream/i.test(type));
      })
      .catch(() => setExists(false))
      .finally(done);
  }, [handle]);

  if (!wanted || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
