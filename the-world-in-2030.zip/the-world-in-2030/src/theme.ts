// theme.ts — রং, ইজিং, spring, ফন্ট ও আকারের একমাত্র উৎস। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
import { Easing } from "remotion";

export const theme = {
  colors: {
    // স্কিম ১ — নিয়ন ফিউচার
    bg: "#050B1E",
    primary: "#2EC8FF", // হিরো
    accent: "#FF8A2B",
    text: "#EAF4FF",
    // একই স্কিম থেকে প্রাপ্ত টিন্ট
    bgAlt: "#0A1633",
    bgDeep: "#030715",
    textDim: "#8CA3C7",
    glow: "rgba(46,200,255,0.45)",
    glowSoft: "rgba(46,200,255,0.16)",
    accentLight: "#FFC48A",
    accentGlow: "rgba(255,138,43,0.5)",
    accentSoft: "rgba(255,138,43,0.16)",
    glass: "rgba(16,36,76,0.62)",
    glassHi: "rgba(60,110,190,0.30)",
    glassEdge: "rgba(150,205,255,0.24)",
    line: "rgba(140,200,255,0.12)",
    lineStrong: "rgba(140,200,255,0.34)",
    shadow: "rgba(0,0,0,0.55)",
    white: "#FFFFFF",
    // গ্লোব ও শহরের স্তর
    globeLit: "#12366F",
    globeMid: "#08183A",
    globeDark: "#030815",
    cityFar: "#0A1735",
    cityMid: "#0D1D45",
    road: "#070F26",
    carBody: "#DCEBFF",
    carGlass: "#0B1A3D",
  },
  fonts: {
    // Hind Siliguri-র ফাইল public/fonts/-এ দিলে সেটাই ব্যবহার হবে; না দিলে প্রজেক্টের FreeSans (বাংলা সাপোর্টসহ)।
    display: '"Hind Siliguri", "BanglaBase", "FreeSans", sans-serif',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  radius: { card: 40, small: 20, pill: 999 },
  weight: { hero: 700, body: 500 },
  size: { mega: 330, hero: 190, title: 128, head: 100, sub: 72, body: 56, small: 38 },
  shadow: {
    card: "0 40px 90px -24px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,255,255,0.16)",
    glow: "0 0 70px rgba(46,200,255,0.4), 0 0 140px rgba(46,200,255,0.18)",
    accentGlow: "0 0 70px rgba(255,138,43,0.4), 0 0 140px rgba(255,138,43,0.16)",
  },
} as const;

export type Tint = "primary" | "accent";
