import React from "react";
import { theme } from "../theme";
import { DrawPath } from "./core";

type IP = { size: number; p?: number; color?: string; fillColor?: string; glow?: boolean };
const svg = (size: number, children: React.ReactNode) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible" }}>{children}</svg>
);
const soft = (c: string) => c + "22";

export const PersonIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.text, glow }) =>
  svg(size, (
    <>
      <circle cx="50" cy="30" r="17" fill={soft(color)} stroke="none" opacity={p} />
      <DrawPath d="M50 13 a17 17 0 1 1 -0.01 0" p={p} color={color} width={3.5} glow={glow} />
      <path d="M18 92 C18 66 32 54 50 54 C68 54 82 66 82 92 Z" fill={soft(color)} opacity={p} />
      <DrawPath d="M18 92 C18 66 32 54 50 54 C68 54 82 66 82 92" p={p} color={color} width={3.5} glow={glow} />
    </>
  ));

export const RobotIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.primary, glow }) =>
  svg(size, (
    <>
      <rect x="22" y="28" width="56" height="44" rx="14" fill={soft(color)} opacity={p} />
      <DrawPath d="M36 28 H64 a14 14 0 0 1 14 14 V58 a14 14 0 0 1 -14 14 H36 a14 14 0 0 1 -14 -14 V42 a14 14 0 0 1 14 -14 Z" p={p} color={color} width={3.5} glow={glow} />
      <DrawPath d="M50 28 V14" p={p} color={color} width={3.5} />
      <circle cx="50" cy="11" r="4.5" fill={color} opacity={p} />
      <DrawPath d="M14 42 V58 M86 42 V58" p={p} color={color} width={5} />
      <circle cx="38" cy="48" r="6" fill={color} opacity={p} />
      <circle cx="62" cy="48" r="6" fill={color} opacity={p} />
      <DrawPath d="M38 61 H62" p={p} color={color} width={3.5} />
      <DrawPath d="M32 78 H68 V90 a4 4 0 0 1 -4 4 H36 a4 4 0 0 1 -4 -4 Z" p={p} color={color} width={3.5} />
    </>
  ));

export const ChipIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.primary, glow }) =>
  svg(size, (
    <>
      <rect x="26" y="26" width="48" height="48" rx="9" fill={soft(color)} opacity={p} />
      <DrawPath d="M35 26 H65 a9 9 0 0 1 9 9 V65 a9 9 0 0 1 -9 9 H35 a9 9 0 0 1 -9 -9 V35 a9 9 0 0 1 9 -9 Z" p={p} color={color} width={3.5} glow={glow} />
      <DrawPath d="M40 40 H60 V60 H40 Z" p={p} color={color} width={3} />
      <DrawPath d="M38 26 V12 M50 26 V12 M62 26 V12 M38 74 V88 M50 74 V88 M62 74 V88 M26 38 H12 M26 50 H12 M26 62 H12 M74 38 H88 M74 50 H88 M74 62 H88" p={p} color={color} width={3.5} />
    </>
  ));

export const CapIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.primary, glow }) =>
  svg(size, (
    <>
      <path d="M50 22 L92 40 L50 58 L8 40 Z" fill={soft(color)} opacity={p} />
      <DrawPath d="M50 22 L92 40 L50 58 L8 40 Z" p={p} color={color} width={3.5} glow={glow} />
      <DrawPath d="M26 50 V68 C26 78 74 78 74 68 V50" p={p} color={color} width={3.5} />
      <DrawPath d="M86 43 V70" p={p} color={color} width={3.5} />
      <circle cx="86" cy="75" r="4.5" fill={color} opacity={p} />
    </>
  ));

export const ShieldIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.primary, glow }) =>
  svg(size, (
    <>
      <path d="M50 8 L86 22 V50 C86 72 70 86 50 94 C30 86 14 72 14 50 V22 Z" fill={soft(color)} opacity={p} />
      <DrawPath d="M50 8 L86 22 V50 C86 72 70 86 50 94 C30 86 14 72 14 50 V22 Z" p={p} color={color} width={3.5} glow={glow} />
      <rect x="36" y="46" width="28" height="22" rx="5" fill={color} opacity={p * 0.9} />
      <DrawPath d="M41 46 V40 C41 30 59 30 59 40 V46" p={p} color={color} width={4} />
      <circle cx="50" cy="56" r="3.2" fill={theme.colors.bg} opacity={p} />
    </>
  ));

export const BuildingIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.primary }) =>
  svg(size, (
    <>
      <DrawPath d="M20 92 V30 H52 V92 M52 52 H80 V92 M12 92 H88" p={p} color={color} width={3.5} />
      <DrawPath d="M30 42 H42 M30 56 H42 M30 70 H42 M62 64 H70 M62 78 H70" p={p} color={color} width={3.5} />
    </>
  ));

export const WarnIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.accent, glow }) =>
  svg(size, (
    <>
      <path d="M50 12 L92 86 H8 Z" fill={soft(color)} opacity={p} />
      <DrawPath d="M50 12 L92 86 H8 Z" p={p} color={color} width={4} glow={glow} />
      <DrawPath d="M50 40 V62" p={p} color={color} width={5} />
      <circle cx="50" cy="73" r="3.6" fill={color} opacity={p} />
    </>
  ));

export const CheckIcon: React.FC<IP> = ({ size, p = 1, color = theme.colors.primary }) =>
  svg(size, <DrawPath d="M20 53 L42 74 L80 28" p={p} color={color} width={9} />);

export const ThermoIcon: React.FC<IP & { level?: number }> = ({ size, p = 1, color = theme.colors.accent, level = 1, glow }) =>
  svg(size, (
    <>
      <DrawPath d="M42 60 V18 a8 8 0 0 1 16 0 V60 a17 17 0 1 1 -16 0 Z" p={p} color={color} width={3.5} glow={glow} />
      <circle cx="50" cy="76" r="9.5" fill={color} opacity={p} />
      <rect x="47" y={66 - 44 * level} width="6" height={10 + 44 * level} rx="3" fill={color} opacity={p} />
      <DrawPath d="M66 26 H74 M66 38 H72 M66 50 H74" p={p} color={color} width={3} />
    </>
  ));
