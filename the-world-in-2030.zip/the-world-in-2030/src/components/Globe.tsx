import React from "react";
import { theme } from "../theme";
import { rnd } from "./core";

const R = 380;
const TILT = 0.38;
const FIB = Array.from({ length: 1250 }, (_, i) => {
  const y = 1 - (i / 1249) * 2;
  const r = Math.sqrt(1 - y * y);
  const th = i * 2.399963;
  return { lat: Math.asin(y), lon: th };
});
const CITIES = Array.from({ length: 95 }, (_, i) => ({ lat: ((rnd(i * 5 + 1) - 0.5) * 2 * 52 * Math.PI) / 180, lon: rnd(i * 5 + 2) * Math.PI * 2, s: 2.4 + rnd(i * 5 + 3) * 3.4, ph: rnd(i * 5 + 4) * 6.28 }));

const proj = (lat: number, lon: number, rot: number) => {
  const l = lon + rot;
  const x = Math.cos(lat) * Math.sin(l);
  const y0 = Math.sin(lat);
  const z0 = Math.cos(lat) * Math.cos(l);
  const y = y0 * Math.cos(TILT) - z0 * Math.sin(TILT);
  const z = y0 * Math.sin(TILT) + z0 * Math.cos(TILT);
  return { x: 500 + x * R, y: 500 - y * R, z };
};

/** ডট-ম্যাট্রিক্স গ্লোব — রাতের শহরের আলো (কমলা) ও সূর্যোদয়ের ঝলক সহ */
export const Globe: React.FC<{ size: number; rot: number; frame: number; glow?: number; lights?: number }> = ({ size, rot, frame, glow = 1, lights = 1 }) => {
  const rr = (rot * Math.PI) / 180;
  const ring = (t: number) => ({ x: 500 + 470 * Math.cos(t), y: 500 + 150 * Math.sin(t) });
  const sat = ring(frame / 38);
  return (
    <svg width={size} height={size} viewBox="0 0 1000 1000" style={{ overflow: "visible" }}>
      <defs>
        <radialGradient id="gSphere" cx="35%" cy="30%" r="80%">
          <stop offset="0%" stopColor={theme.colors.globeLit} />
          <stop offset="55%" stopColor={theme.colors.globeMid} />
          <stop offset="100%" stopColor={theme.colors.globeDark} />
        </radialGradient>
        <radialGradient id="gAtmos" cx="50%" cy="50%" r="50%">
          <stop offset="68%" stopColor={theme.colors.primary} stopOpacity="0" />
          <stop offset="76%" stopColor={theme.colors.primary} stopOpacity={0.32 * glow} />
          <stop offset="100%" stopColor={theme.colors.primary} stopOpacity="0" />
        </radialGradient>
        <radialGradient id="gSun" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={theme.colors.accent} stopOpacity="0.9" />
          <stop offset="100%" stopColor={theme.colors.accent} stopOpacity="0" />
        </radialGradient>
        <clipPath id="gClip"><circle cx="500" cy="500" r={R} /></clipPath>
      </defs>
      <circle cx="500" cy="500" r={R * 1.38} fill="url(#gAtmos)" />
      <circle cx="500" cy="500" r={R} fill="url(#gSphere)" />
      <g clipPath="url(#gClip)">
        {FIB.map((d, i) => {
          const q = proj(d.lat, d.lon, rr);
          if (q.z <= 0) return null;
          return <circle key={i} cx={q.x} cy={q.y} r={1.6 + q.z * 1.5} fill={theme.colors.primary} opacity={0.12 + q.z * 0.5} />;
        })}
        {CITIES.map((c, i) => {
          const q = proj(c.lat, c.lon, rr);
          if (q.z <= 0.05) return null;
          const tw = 0.6 + 0.4 * Math.sin(frame / 14 + c.ph);
          return (
            <g key={i} opacity={lights * tw * Math.min(1, q.z * 2)}>
              <circle cx={q.x} cy={q.y} r={c.s * 2.6} fill={theme.colors.accent} opacity={0.22} />
              <circle cx={q.x} cy={q.y} r={c.s * 0.8} fill={theme.colors.accent} />
            </g>
          );
        })}
        <circle cx={500 + R * 0.74} cy={500 - R * 0.6} r="230" fill="url(#gSun)" opacity={0.7 * glow} />
      </g>
      <circle cx="500" cy="500" r={R} fill="none" stroke={theme.colors.primary} strokeWidth="3" opacity={0.7 * glow} style={{ filter: `drop-shadow(0 0 18px ${theme.colors.primary})` }} />
      <g transform="rotate(-18 500 500)">
        <ellipse cx="500" cy="500" rx="470" ry="150" fill="none" stroke={theme.colors.primary} strokeWidth="2" strokeDasharray="3 12" opacity={0.55} />
        <circle cx={sat.x} cy={sat.y} r="9" fill={theme.colors.text} style={{ filter: `drop-shadow(0 0 12px ${theme.colors.primary})` }} />
      </g>
    </svg>
  );
};
