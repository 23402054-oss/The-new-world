import React, { createContext, useContext } from "react";
import { AbsoluteFill, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { LEAD } from "../config";

const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** 0→1 প্রগ্রেস (clamp করা, ইজিংসহ) */
export const prog = (frame: number, start: number, dur: number, easing: (t: number) => number = theme.ease.out) =>
  interpolate(frame, [start, start + dur], [0, 1], { easing, ...CL });

export const useSp = (start = 0, cfg: { damping: number; stiffness: number; mass: number } = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - start, fps, config: cfg });
};

// ---------------- সিন কনটেক্সট (সব টাইমিং SRT থেকে) ----------------
export type SceneInfo = {
  index: number;
  localCueStart: number; // সিন-লোকাল ফ্রেমে cue শুরু
  cueFrames: number;
  lines: string[];
  exitEnd: number;
  dur: number;
  isLast: boolean;
};
const Ctx = createContext<SceneInfo>({ index: 0, localCueStart: 0, cueFrames: 300, lines: [""], exitEnd: 300, dur: 300, isLast: false });
export const SceneProvider = Ctx.Provider;

export const useScene = () => {
  const s = useContext(Ctx);
  /** k-তম লাইনের জন্য ভিজ্যুয়াল শুরু: cue-কে লাইনসংখ্যায় সমান ভাগ করে, LEAD ফ্রেম আগে */
  const beat = (k: number) => Math.max(0, s.localCueStart + Math.round((k * s.cueFrames) / s.lines.length) - LEAD);
  const beatEnd = (k: number) => (k + 1 >= s.lines.length ? s.exitEnd : beat(k + 1));
  return { ...s, beat, beatEnd };
};

/** একটি বিট: নিজের সময়ে ঢোকে, পরের বিটের আগে দ্রুত বেরোয়। ভেতরের frame বিট-লোকাল। */
export const Beat: React.FC<{ k: number; children: React.ReactNode; exit?: boolean }> = ({ k, children, exit = true }) => {
  const sc = useScene();
  const frame = useCurrentFrame();
  const start = sc.beat(k);
  const end = sc.beatEnd(k);
  const last = k === sc.lines.length - 1;
  const out = exit && !last ? prog(frame, end - 10, 9, theme.ease.in) : 0;
  return (
    <Sequence from={start} durationInFrames={Math.max(1, end - start + (last ? 0 : 1))} layout="none">
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 1 - out,
          transform: `translateY(${-out * 46}px) scale(${1 + out * 0.03})`,
          filter: out > 0 ? `blur(${out * 12}px)` : undefined,
        }}
      >
        {children}
      </div>
    </Sequence>
  );
};

// ---------------- ব্যাকগ্রাউন্ড ও ফিনিশিং স্তর ----------------
const rnd = (seed: number) => {
  let a = seed + 0x6d2b79f5;
  a = Math.imul(a ^ (a >>> 15), a | 1);
  a ^= a + Math.imul(a ^ (a >>> 7), a | 61);
  return ((a ^ (a >>> 14)) >>> 0) / 4294967296;
};
export { rnd };

const DUST = Array.from({ length: 46 }, (_, i) => ({ x: rnd(i * 3 + 1) * 1920, y: rnd(i * 3 + 2) * 1080, r: 1.2 + rnd(i * 3 + 3) * 2.4, s: 0.3 + rnd(i + 90) * 0.9, p: rnd(i + 190) * 6.28 }));

export const BgMesh: React.FC<{ accentMix?: number }> = ({ accentMix = 0 }) => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  const c = theme.colors;
  return (
    <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 0%, ${c.bgAlt}, ${c.bg} 62%, ${c.bgDeep})` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -380 + d1, filter: "blur(60px)", opacity: 1 - accentMix * 0.9, background: `radial-gradient(circle, ${c.glow}, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -460, right: -260 - d2, filter: "blur(80px)", opacity: 0.7, background: `radial-gradient(circle, ${c.glowSoft}, transparent 65%)` }} />
      <div style={{ position: "absolute", width: 1400, height: 1100, borderRadius: "50%", top: -300, left: 300 - d2, filter: "blur(80px)", opacity: accentMix, background: `radial-gradient(circle, ${c.accentGlow}, transparent 64%)` }} />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(${c.line} 1px, transparent 1px), linear-gradient(90deg, ${c.line} 1px, transparent 1px)`,
          backgroundSize: "96px 96px",
          backgroundPosition: `${-(frame * 0.35) % 96}px ${-(frame * 0.2) % 96}px`,
          WebkitMaskImage: "radial-gradient(ellipse at 50% 45%, black 10%, transparent 72%)",
          maskImage: "radial-gradient(ellipse at 50% 45%, black 10%, transparent 72%)",
          opacity: 0.8,
        }}
      />
      {DUST.map((d, i) => (
        <div key={i} style={{ position: "absolute", left: d.x, top: (d.y - frame * d.s * 0.6 + 1080 * 3) % 1080, width: d.r * 2, height: d.r * 2, borderRadius: "50%", background: accentMix > 0.5 && i % 3 === 0 ? theme.colors.accent : theme.colors.text, opacity: 0.1 + 0.16 * (0.5 + 0.5 * Math.sin(frame / 20 + d.p)) }} />
      ))}
    </AbsoluteFill>
  );
};

const NOISE = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;

export const Finish: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill style={{ pointerEvents: "none" }}>
        <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.16 }} />
        <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.14), transparent 26%, transparent 72%, rgba(0,0,0,0.24))" }} />
      </AbsoluteFill>
      <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: NOISE, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.05, mixBlendMode: "overlay" }} />
      <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)" }} />
    </>
  );
};

/** প্রতি সিনের ৫-স্তর শেল: bg mesh → কনটেন্ট → গ্রেড → গ্রেইন → ভিনিয়েট */
export const SceneShell: React.FC<{ children: React.ReactNode; accentMix?: number; fadeOut?: boolean }> = ({ children, accentMix = 0, fadeOut = false }) => {
  const frame = useCurrentFrame();
  const sc = useScene();
  const out = prog(frame, sc.exitEnd - 11, 10, theme.ease.in);
  const o = fadeOut ? 1 - out : 1 - out * 0.9;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <BgMesh accentMix={accentMix} />
      <AbsoluteFill style={{ opacity: o, transform: `translateX(${-out * 60}px) scale(${1 + out * 0.02})`, filter: out > 0 ? `blur(${out * 10}px)` : undefined }}>{children}</AbsoluteFill>
      <Finish />
    </AbsoluteFill>
  );
};

// ---------------- টেক্সট ----------------
const grad = () => `linear-gradient(95deg, ${theme.colors.primary} 10%, ${theme.colors.text} 120%)`;
const gradAcc = () => `linear-gradient(95deg, ${theme.colors.accent} 10%, ${theme.colors.accentLight} 130%)`;

type WordsProps = {
  text: string;
  start?: number;
  per?: number;
  size: number;
  color?: string;
  align?: "left" | "center" | "right";
  hi?: number[]; // গ্র্যাডিয়েন্ট কীওয়ার্ডের ইনডেক্স
  hiAccent?: boolean;
  maxWidth?: number;
  lineHeight?: number;
  weight?: number;
  style?: React.CSSProperties;
};
/** শব্দ-বাই-শব্দ স্ট্যাগার্ড। বিভাজন শুধু স্পেসে — বাংলা অক্ষর কখনো ভাঙে না। */
export const Words: React.FC<WordsProps> = ({ text, start = 0, per = 4, size, color, align = "left", hi = [], hiAccent = false, maxWidth, lineHeight = 1.32, weight = theme.weight.hero, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: Math.round(size * 0.27),
        justifyContent: align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start",
        maxWidth,
        fontFamily: theme.fonts.display,
        fontWeight: weight,
        fontSize: size,
        lineHeight,
        letterSpacing: 0,
        color: color ?? theme.colors.text,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const p = spring({ frame: frame - start - i * per, fps, config: theme.spring.snappy });
        const isHi = hi.includes(i);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.4),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
              filter: `blur(${interpolate(p, [0, 1], [10, 0], CL)}px)${isHi ? ` drop-shadow(0 0 22px ${hiAccent ? theme.colors.accentGlow : theme.colors.glow})` : ""}`,
              padding: "0.04em 0.03em",
              ...(isHi ? { backgroundImage: hiAccent ? gradAcc() : grad(), WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent" } : null),
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** লাইন মাস্ক রিভিল — নিচ থেকে উঠে আসে (বাংলা মাত্রা/নিচের চিহ্ন কাটা পড়ে না: পর্যাপ্ত padding) */
export const MaskLine: React.FC<{ children: React.ReactNode; start?: number; style?: React.CSSProperties }> = ({ children, start = 0, style }) => {
  const frame = useCurrentFrame();
  const p = prog(frame, start, 22, theme.ease.out);
  return (
    <div style={{ overflow: "hidden", padding: "0.34em 0.12em 0.34em", margin: "-0.34em -0.12em", ...style }}>
      <div style={{ transform: `translateY(${(1 - p) * 115}%)`, opacity: Math.min(1, p * 3) }}>{children}</div>
    </div>
  );
};

/** হাইলাইট সুইপ: শব্দের পেছনে পিল ডানে প্রসারিত হয় */
export const Sweep: React.FC<{ children: React.ReactNode; start: number; accent?: boolean }> = ({ children, start, accent }) => {
  const frame = useCurrentFrame();
  const p = prog(frame, start, 16, theme.ease.out);
  return (
    <span style={{ position: "relative", display: "inline-block", isolation: "isolate", padding: "0 0.22em" }}>
      <span style={{ position: "absolute", left: 0, right: 0, top: "0.12em", bottom: "0.02em", borderRadius: 22, zIndex: -1, transformOrigin: "left center", transform: `scaleX(${p})`, background: accent ? theme.colors.accentSoft : theme.colors.glassHi, border: `2px solid ${accent ? theme.colors.accent : theme.colors.primary}`, boxShadow: accent ? theme.shadow.accentGlow : theme.shadow.glow }} />
      {children}
    </span>
  );
};

export const Pill: React.FC<{ children: React.ReactNode; accent?: boolean; size?: number; style?: React.CSSProperties }> = ({ children, accent, size = 34, style }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 14, padding: "10px 28px", borderRadius: theme.radius.pill, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: size, lineHeight: 1.3, color: accent ? theme.colors.accent : theme.colors.primary, background: accent ? theme.colors.accentSoft : theme.colors.glowSoft, border: `2px solid ${accent ? theme.colors.accent : theme.colors.primary}55`, ...style }}>{children}</div>
);

export const Glass: React.FC<{ style?: React.CSSProperties; children?: React.ReactNode; accent?: boolean }> = ({ style, children, accent }) => (
  <div
    style={{
      position: "absolute",
      borderRadius: theme.radius.card,
      background: `linear-gradient(150deg, ${theme.colors.glassHi}, ${theme.colors.glass} 45%)`,
      border: `1.5px solid ${accent ? theme.colors.accent + "88" : theme.colors.glassEdge}`,
      boxShadow: theme.shadow.card,
      overflow: "hidden",
      ...style,
    }}
  >
    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(115deg, rgba(255,255,255,0.10), rgba(255,255,255,0) 32%)", pointerEvents: "none" }} />
    {children}
  </div>
);

/** স্ট্রোক আঁকা (Line Draw) */
export const DrawPath: React.FC<{ d: string; p: number; color?: string; width?: number; fill?: string; glow?: boolean; opacity?: number }> = ({ d, p, color = theme.colors.primary, width = 4, fill = "none", glow = false, opacity = 1 }) => (
  <path d={d} pathLength={1} fill={fill} stroke={color} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={1} strokeDashoffset={1 - p} opacity={opacity} style={glow ? { filter: `drop-shadow(0 0 8px ${color})` } : undefined} />
);

export const useBreathe = (phase = 0) => {
  const frame = useCurrentFrame();
  return { s: 1 + Math.sin(frame / 22 + phase) * 0.015, y: Math.sin(frame / 30 + phase) * 6 };
};
