import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { prog } from "./core";

/** সিন-সীমায় হুইপ সোয়াইপ: কাটটি আড়াল করে (১৮ ফ্রেম) */
export const Whip: React.FC = () => {
  const frame = useCurrentFrame();
  const p = prog(frame, 0, 18, theme.ease.inOut);
  const x = -2300 + p * 4600;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -200, bottom: -200, left: x - 520, width: 1040, transform: "skewX(-16deg)", filter: "blur(8px)", background: `linear-gradient(90deg, transparent 0%, ${theme.colors.bgDeep} 22%, ${theme.colors.bgDeep} 74%, ${theme.colors.primary} 97%, transparent 100%)` }} />
      <div style={{ position: "absolute", top: -200, bottom: -200, left: x + 360, width: 12, transform: "skewX(-16deg)", background: theme.colors.text, opacity: 0.7, filter: `blur(2px) drop-shadow(0 0 24px ${theme.colors.primary})` }} />
    </AbsoluteFill>
  );
};
