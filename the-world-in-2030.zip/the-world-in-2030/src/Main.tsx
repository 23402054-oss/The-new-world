import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { CUES } from "./cues";
import { FPS, LEAD } from "./config";
import { theme } from "./theme";
import { SceneProvider } from "./components/core";
import { Whip } from "./components/Transition";
import { Sfx } from "./sfx";
import { PreviewAudio } from "./PreviewAudio";
import { FontLoader } from "./fonts";
import { S1 } from "./scenes/S1";
import { S2 } from "./scenes/S2";
import { S3 } from "./scenes/S3";
import { S4 } from "./scenes/S4";
import { S5 } from "./scenes/S5";
import { S6 } from "./scenes/S6";
import { S7 } from "./scenes/S7";

const SCENES = [S1, S2, S3, S4, S5, S6, S7];

// সিনের সীমা = SRT cue-র সীমা। নতুন সিন LEAD ফ্রেম আগে ঢোকে (ভিজ্যুয়াল কথার আগে)।
export const plan = CUES.map((c, i) => {
  const startF = Math.round(c.start * FPS);
  const endF = Math.round(c.end * FPS);
  const from = i === 0 ? 0 : startF - LEAD;
  return { cue: c, from, startF, endF, dur: endF - from, last: i === CUES.length - 1 };
});
export const TOTAL_FRAMES = plan[plan.length - 1].endF;

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    <FontLoader />
    <PreviewAudio />
    {plan.map((s, i) => {
      const Scene = SCENES[i];
      if (!Scene) return null;
      return (
        <Sequence key={s.cue.id} from={s.from} durationInFrames={s.dur} name={`সিন ${i + 1}`}>
          <SceneProvider value={{ index: i, localCueStart: s.startF - s.from, cueFrames: s.endF - s.startF, lines: s.cue.lines, exitEnd: s.dur - (s.last ? 0 : LEAD), dur: s.dur, isLast: s.last }}>
            <Scene />
          </SceneProvider>
        </Sequence>
      );
    })}
    {plan.slice(1).map((s) => (
      <React.Fragment key={`t${s.cue.id}`}>
        <Sequence from={s.from - 8} durationInFrames={18} name="ট্রানজিশন" layout="none">
          <Whip />
        </Sequence>
        <Sfx name="whoosh" at={s.from - 10} />
      </React.Fragment>
    ))}
  </AbsoluteFill>
);
