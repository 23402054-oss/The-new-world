import React, { useEffect, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";

/** ফন্ট সম্পূর্ণ লোকাল (public/fonts) — ইন্টারনেট লাগে না। ফাইল না থাকলে নীরবে পরের ফন্টে যায়। */
export const FontLoader: React.FC = () => {
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => {
    const done = () => continueRender(handle);
    const loads = [
      document.fonts.load('700 48px "BanglaBase"', "আ২০৩০AI"),
      document.fonts.load('700 48px "Hind Siliguri"', "আ২০৩০AI"),
    ];
    Promise.allSettled(loads).then(done, done);
  }, [handle]);
  const css = `
@font-face { font-family: "BanglaBase"; src: url("${staticFile("fonts/FreeSans.ttf")}") format("truetype"); font-weight: 400; font-style: normal; }
@font-face { font-family: "Hind Siliguri"; src: url("${staticFile("fonts/HindSiliguri-Bold.ttf")}") format("truetype"); font-weight: 600 700; font-style: normal; }
`;
  return <style>{css}</style>;
};
