ফন্ট: প্রজেক্টে FreeSans.ttf (বাংলা যুক্তাক্ষরসহ, GPL+font exception) দেওয়া আছে — ইন্টারনেট ছাড়াই চলে।
আরও ভালো ওজনের জন্য Hind Siliguri-র Bold ফাইল এই ফোল্ডারে HindSiliguri-Bold.ttf নামে রাখুন; থাকলে সেটাই ব্যবহার হবে।
